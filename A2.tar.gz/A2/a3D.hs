
module GameLogic where 
import Data.List
data Piece = Red | Yellow 
type Column = [Piece]
type Board = [Column]

data BoardState = BS 
  {
      theBoard :: Board,
      lastMove :: Piece,
      numColumns :: Int,
      numRows :: Int,
      numToConnect :: Int
  }

makeMove :: BoardState -> Int -> Maybe BoardState
makeMove boardState colPicked = Just(BS ((take (colPicked - 1) (theBoard boardState)++ [(((theBoard boardState) !! (colPicked -1))++ [lastMove boardState])]++ (drop colPicked (theBoard boardState))))
							(lastMove boardState) (numColumns boardState) (numRows boardState) (numToConnect boardState))
								
								
legalCheck :: BoardState -> Int -> Bool
legalCheck b c = if 0 < c && c < (numRows b) then True 
				 else False
	
	

changeColor :: Piece -> Piece 
changeColor Red = Yellow 
changeColor Yellow = Red
checkWin :: BoardState -> Maybe Piece
checkWin boardState = if (or[checkRow (theBoard boardState), checkColumn  (theBoard boardState), diagonalCheck ( diagonalsBackward boardState), diagonalCheck (map (\rows -> padN rows (numColumns boardState)) (map (map Just)(transpose (diagonalsForward boardState))))]) == True 
					  then undefined
					  else undefined

rows :: BoardState -> [[Maybe Piece]]
rows bs = map (\rows -> padN rows (numColumns bs)) (map (map Just)(transpose (theBoard bs)))

columns :: BoardState -> [[Maybe Piece]]
columns bs = map (\col -> padN col (numRows bs)) (map (map Just)(theBoard bs))

padN :: [Maybe Piece] -> Int -> [Maybe Piece]
padN xs n =   xs ++  replicate ( n - (length xs )) Nothing 

checkRow :: Board -> Bool 
checkRow = undefined

checkColumn :: Board -> Bool
checkColumn = undefined
 
diagonalCheck :: [[Maybe Piece]] -> Bool 
diagonalCheck b = undefined 


diagonalsForward :: BoardState -> [[Piece]]
diagonalsForward boardState =  
    let n = length (theBoard boardState)
    in [[((theBoard boardState) !! y) !! x | x <- [0..(n - 1)], 
                            y <- [0..(n - 1)], 
                            x + y == numToConnect] 
		| numToConnect <- [0.. 2*(n-1)]]
		    
diagonalsBackward :: BoardState -> [[Maybe Piece]]
diagonalsBackward = undefined
