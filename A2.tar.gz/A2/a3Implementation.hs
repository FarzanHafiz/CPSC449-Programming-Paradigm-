{-	Name: Shah Farzan Al-Hafiz
	ID: 10162590				-}
	

data Piece = Yellow | Red

type Column = [Piece]
type Board = [Column]

